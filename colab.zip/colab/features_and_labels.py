# features_and_labels.py
import pandas as pd
import numpy as np
import glob, os

IN_DIR = "clean_ohlcv"      # giriş klasörü (temiz OHLCV csv)
FEAT_DIR = "features"       # çıkış klasörü (parquet + label)
os.makedirs(FEAT_DIR, exist_ok=True)


# -------------------------------------------
# 1) İNDİKATÖR HESAPLAMA
# -------------------------------------------
def add_indicators(g):
    g = g.copy()

    # Basit getiriler
    g["ret"] = g["close"].pct_change().fillna(0.0)
    g["log_ret"] = np.log(g["close"]).diff().fillna(0.0)

    # SMA
    g["sma5"] = g["close"].rolling(5).mean()
    g["sma10"] = g["close"].rolling(10).mean()

    # EMA
    g["ema12"] = g["close"].ewm(span=12, adjust=False).mean()
    g["ema26"] = g["close"].ewm(span=26, adjust=False).mean()

    # RSI (14)
    delta = g["close"].diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)

    roll_up = up.rolling(14).mean()
    roll_down = down.rolling(14).mean()
    rs = roll_up / (roll_down + 1e-9)
    g["rsi14"] = 100 - (100 / (1 + rs))

    # Volatilite
    g["volatility_10"] = g["ret"].rolling(10).std()

    # Modern fill (futureWarning yok)
    g = g.bfill().ffill()

    return g


# -------------------------------------------
# 2) LABEL OLUŞTURMA (FUTURE STEPS = 5)
# -------------------------------------------
def create_label(g, future_steps=5, threshold=0.0):
    g = g.copy()

    g["future_price"] = g["close"].shift(-future_steps)

    # 5-bar forward return
    g["future_return"] = (
        (g["future_price"] - g["close"]) /
        (g["close"] + 1e-12)  # 0 bölme koruması
    )

    # Binary label (0/1)
    g["label_binary"] = (g["future_return"] > threshold).astype(int)

    # Fazla geçici kolonu sil
    g = g.drop(columns=["future_price"])

    return g


# -------------------------------------------
# 3) TÜM DOSYALARI İŞLE
# -------------------------------------------
files = sorted(glob.glob(f"{IN_DIR}/*.csv"))

for f in files:
    df = pd.read_csv(f, parse_dates=["timestamp"])
    df = df.sort_values("timestamp").reset_index(drop=True)

    # indikatör
    df2 = add_indicators(df)

    # label
    df2 = create_label(df2, future_steps=5, threshold=0.0)

    # Kaydet
    base = os.path.basename(f).replace(".csv", ".parquet")
    out = os.path.join(FEAT_DIR, base)
    df2.to_parquet(out, index=False)

    print("Saved", out, "rows:", len(df2))
