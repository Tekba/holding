# save_sequences_v3_with_meta.py
import os, glob, json
import numpy as np
import pandas as pd
from tqdm import tqdm
import joblib

IN_DIR = "features_v3"
OUT_DIR = "sequences_v5"
SCALER_DIR = os.path.join("models_v5", "scalers")
MAP_DIR = "models_v5"
SEQ_LEN = 64

FEATURE_COLS = [
    "open","high","low","close","volume","log_ret",
    "sma5","sma10","sma20","ema12","ema26","ema50",
    "rsi14","macd","macd_signal","roc10","cci20",
    "atr14","bollinger_upper","bollinger_lower","bollinger_width",
    "candle_body","wick_up","wick_down",
    "vol_change","close_sma10_ratio","price_range"
]

os.makedirs(OUT_DIR, exist_ok=True)
with open(os.path.join(MAP_DIR, "pair2id.json")) as f: pair2id = json.load(f)
with open(os.path.join(MAP_DIR, "tf2id.json")) as f: tf2id = json.load(f)

files = sorted(glob.glob(os.path.join(IN_DIR, "*.parquet")))
if not files:
    raise SystemExit("No normalized files in features_v3")

X_parts = []
y_parts = []

print("Processing files and building sequences (this may take a few minutes)...")
for p in files:
    try:
        df = pd.read_parquet(p).sort_values("timestamp").reset_index(drop=True)
        fname = os.path.basename(p)
        pair = fname.split("_")[0]
        tf = fname.split("_")[1].replace(".parquet","")
        pair_id = pair2id.get(pair)
        tf_id = tf2id.get(tf)
        if pair_id is None or tf_id is None:
            print("mapping missing for", fname); continue

        if "future_return" not in df.columns:
            print("No future_return:", fname); continue

        n = len(df)
        if n < SEQ_LEN+1:
            print("too short:", fname); continue

        # build numpy array of features (already normalized per-file)
        X = df[FEATURE_COLS].astype(np.float32).values
        y_raw = (df["future_return"] > 0).astype(np.int64).values

        N = n - SEQ_LEN
        # index trick to build rolling windows efficiently
        idx = (np.arange(SEQ_LEN)[None, :] + np.arange(N)[:, None]).astype(np.int64)
        X_seq = X[idx]  # shape (N, SEQ_LEN, F)
        y_seq = y_raw[SEQ_LEN:]  # labels aligned with last index

        # append meta features as constant columns
        # create (N, SEQ_LEN, 2) meta array filled with pair_id and tf_id
        meta = np.empty((X_seq.shape[0], X_seq.shape[1], 2), dtype=np.float32)
        meta.fill(0.0)
        meta[..., 0] = float(pair_id)
        meta[..., 1] = float(tf_id)

        X_with_meta = np.concatenate([X_seq, meta], axis=2)  # new F = 27 + 2 = 29

        # optionally save per-file partials to disk to avoid huge memory
        part_X_path = os.path.join(OUT_DIR, os.path.splitext(fname)[0] + "_X.npy")
        part_y_path = os.path.join(OUT_DIR, os.path.splitext(fname)[0] + "_y.npy")
        np.save(part_X_path, X_with_meta)
        np.save(part_y_path, y_seq)
        print("Saved partial:", os.path.basename(part_X_path), X_with_meta.shape)
        X_parts.append(part_X_path)
        y_parts.append(part_y_path)

    except Exception as e:
        print("Error", p, e)

# Now concatenate all parts into final X.npy / y.npy (streaming)
print("Concatenating partial files...")
total_X = []
total_y = []
for xp in X_parts:
    arr = np.load(xp, mmap_mode="r")
    total_X.append(arr)
for yp in y_parts:
    arr = np.load(yp, mmap_mode="r")
    total_y.append(arr)

X_final = np.concatenate(total_X, axis=0)
y_final = np.concatenate(total_y, axis=0)

print("Final shapes:", X_final.shape, y_final.shape)
np.save(os.path.join(OUT_DIR, "X.npy"), X_final.astype(np.float32))
np.save(os.path.join(OUT_DIR, "y.npy"), y_final.astype(np.int64))
print("Saved final sequences to", OUT_DIR)

# cleanup partials (optional)
# for f in X_parts + y_parts: os.remove(f)
