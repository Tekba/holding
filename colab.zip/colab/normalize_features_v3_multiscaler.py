# normalize_features_v3_multiscaler.py
import os, glob, json
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler
import joblib

RAW_DIR = "features"
OUT_DIR = "features_v3"
SCALER_DIR = os.path.join("models_v5", "scalers")
os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(SCALER_DIR, exist_ok=True)

# same feature list as v2 (27)
FEATURE_COLS = [
    "open","high","low","close","volume","log_ret",
    "sma5","sma10","sma20","ema12","ema26","ema50",
    "rsi14","macd","macd_signal","roc10","cci20",
    "atr14","bollinger_upper","bollinger_lower","bollinger_width",
    "candle_body","wick_up","wick_down",
    "vol_change","close_sma10_ratio","price_range"
]

exclude = {"timestamp", "label_binary", "future_return"}

parquets = sorted(glob.glob(os.path.join(RAW_DIR, "*.parquet")))
if not parquets:
    raise SystemExit("No raw parquet files in 'features' folder.")

pair_set = set()
tf_set = set()

# helpers
def sma(s, n): return s.rolling(n).mean()
def ema(s, n): return s.ewm(span=n, adjust=False).mean()
def rsi(series, n=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ma_up = up.ewm(alpha=1/n, adjust=False).mean()
    ma_down = down.ewm(alpha=1/n, adjust=False).mean()
    rs = ma_up / (ma_down + 1e-9)
    return 100 - (100 / (1 + rs))
def atr(df, n=14):
    high_low = df['high'] - df['low']
    high_close = (df['high'] - df['close'].shift()).abs()
    low_close = (df['low'] - df['close'].shift()).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    return tr.rolling(n).mean()
def roc(series, n=10): return (series / series.shift(n) - 1) * 100
def cci(df, n=20):
    tp = (df['high'] + df['low'] + df['close']) / 3
    ma = tp.rolling(n).mean()
    md = tp.rolling(n).apply(lambda x: np.mean(np.abs(x - np.mean(x))), raw=True)
    return (tp - ma) / (0.015 * (md + 1e-9))

print("Found", len(parquets), "raw files. Processing...")

for p in parquets:
    try:
        df = pd.read_parquet(p).copy()
        df = df.sort_values("timestamp").reset_index(drop=True)

        # identify pair & timeframe
        fname = os.path.basename(p)
        if "_" not in fname:
            print("Skipping unexpected filename:", fname); continue
        pair = fname.split("_")[0]
        tf = fname.split("_")[1].replace(".parquet","")
        pair_set.add(pair)
        tf_set.add(tf)

        # compute indicators
        df["log_ret"] = np.log(df["close"].replace(0, np.nan)).diff().fillna(0)
        df["sma5"] = sma(df["close"], 5)
        df["sma10"] = sma(df["close"], 10)
        df["sma20"] = sma(df["close"], 20)
        df["ema12"] = ema(df["close"], 12)
        df["ema26"] = ema(df["close"], 26)
        df["ema50"] = ema(df["close"], 50)
        df["rsi14"] = rsi(df["close"], 14)
        macd_line = ema(df["close"], 12) - ema(df["close"], 26)
        df["macd"] = macd_line
        df["macd_signal"] = ema(macd_line, 9)
        df["roc10"] = roc(df["close"], 10)
        df["cci20"] = cci(df, 20)
        df["atr14"] = atr(df, 14)
        sma20 = df["close"].rolling(20).mean()
        std20 = df["close"].rolling(20).std()
        df["bollinger_upper"] = sma20 + 2 * std20
        df["bollinger_lower"] = sma20 - 2 * std20
        df["bollinger_width"] = (df["bollinger_upper"] - df["bollinger_lower"]) / (sma20 + 1e-9)
        df["candle_body"] = df["close"] - df["open"]
        df["wick_up"] = df["high"] - df[["open","close"]].max(axis=1)
        df["wick_down"] = df[["open","close"]].min(axis=1) - df["low"]
        df["price_range"] = df["high"] - df["low"]
        df["vol_change"] = df["volume"].pct_change().fillna(0)
        df["close_sma10_ratio"] = df["close"] / (df["sma10"] + 1e-9)

        # fill NaNs and ensure cols present
        for c in FEATURE_COLS:
            if c not in df.columns:
                df[c] = 0.0
            else:
                df[c] = df[c].fillna(0.0)

        # fit scaler for this file (per-dataset scaler)
        X = df[FEATURE_COLS].astype(np.float32).values
        scaler = RobustScaler().fit(X)
        scaler_path = os.path.join(SCALER_DIR, f"{pair}_{tf}_scaler.pkl")
        joblib.dump(scaler, scaler_path)

        # transform and save normalized parquet
        X_t = scaler.transform(X)
        X_t = np.nan_to_num(X_t, nan=0.0, posinf=1.0, neginf=-1.0)
        df_norm = df.copy()
        df_norm[FEATURE_COLS] = X_t
        out = os.path.join(OUT_DIR, os.path.basename(p))
        df_norm.to_parquet(out, index=False)

        print("Saved normalized:", out, "scaler:", scaler_path)

    except Exception as e:
        print("Error processing", p, e)

# save mapping
pair_list = sorted(list(pair_set))
tf_list = sorted(list(tf_set), key=lambda x: ["1m","5m","15m","1h","4h"].index(x) if x in ["1m","5m","15m","1h","4h"] else x)
pair2id = {p:i for i,p in enumerate(pair_list)}
tf2id = {t:i for i,t in enumerate(tf_list)}
with open(os.path.join("models_v5", "pair2id.json"), "w") as f:
    json.dump(pair2id, f, indent=2)
with open(os.path.join("models_v5", "tf2id.json"), "w") as f:
    json.dump(tf2id, f, indent=2)

print("Done. Pair count:", len(pair_list), "TF count:", len(tf_list))
print("pair2id saved to models_v5/pair2id.json")
print("tf2id saved to models_v5/tf2id.json")
